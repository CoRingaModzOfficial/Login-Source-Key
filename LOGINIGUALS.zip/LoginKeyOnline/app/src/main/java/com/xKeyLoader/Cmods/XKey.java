package com.xKeyLoader.Cmods;


/*
Credits CoRingaModz
Telegram @CoRingaModzYT

*/

import android.content.Context;
import android.widget.LinearLayout;
import android.view.ViewGroup;
import android.widget.EditText;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;
import android.text.ClipboardManager;
import android.content.ClipData;
import android.view.View;
import android.os.Process;
import android.widget.TextView;
import android.graphics.Color;

public class XKey {
    
    private AlertDialog.Builder dialog;
    private AlertDialog.Builder popuperrror;
    
    public static void Start(final Context MrEzCheats) {
        
        AlertDialog.Builder dialog = new AlertDialog.Builder(MrEzCheats);
        final AlertDialog.Builder popuperrror = new AlertDialog.Builder(MrEzCheats);
        dialog.setCancelable(false);
        popuperrror.setCancelable(false);
        
        ////**********////
        
        dialog.setTitle("-Licença Key!!!");
        dialog.setMessage("Ola Mano Eita");
        
        LinearLayout mylayout = new LinearLayout(MrEzCheats);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        mylayout.setLayoutParams(params); mylayout.setOrientation(LinearLayout.VERTICAL);

        
        final TextView addkey = new TextView(MrEzCheats);
        addkey.setTextColor(Color.BLACK);
        addkey. setText("     Input Key (Enter as Key)");
        addkey.setTextSize(12.0F);
        
        
        final EditText myedittext = new EditText(MrEzCheats);
        myedittext.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
       
        final TextView licence = new TextView(MrEzCheats);
        licence.setTextColor(Color.BLACK);
        licence. setText("     Get Licença (Enter as Licença)");
        licence.setTextSize(12.0F);
        
        
        final EditText myedittext2 = new EditText(MrEzCheats);
        myedittext2.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
      
        mylayout.addView(addkey);
        mylayout.addView(myedittext);
        
        mylayout.addView(licence);
        mylayout.addView(myedittext2);
        dialog.setView(mylayout);
        myedittext.setHint(" ");
        myedittext2.setHint(" ");
        dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface _dialog, int _which) {
                    if (myedittext.getText().toString().equals("CORINGA")) {/*
                        startService(new Intent(MainActivity.this, FloatingViewService.class));*/
                      //  Toast.makeText(getApplicationContext(), "Welcome", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        popuperrror.setMessage("Wrong Key!!");
                        popuperrror.setPositiveButton("EXIT", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface _dialog, int _which) {
                                    Toast.makeText(MrEzCheats, "Key Error...", Toast.LENGTH_SHORT).show();
                                    Process.killProcess(Process.myPid());
                                }
                            });
                        popuperrror.create().show();
                    }
                }
            });
        dialog.setNegativeButton("ADMIN", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface _dialog, int _which) {
                    
                    
                }
            });
        dialog.create().show();
    }
}
